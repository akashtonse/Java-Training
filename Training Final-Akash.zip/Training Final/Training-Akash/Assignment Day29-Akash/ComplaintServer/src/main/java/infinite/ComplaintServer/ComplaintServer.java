package infinite.ComplaintServer;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/comp")
public class ComplaintServer {
	
	@GET
	@Path("/show")
	@Produces(MediaType.APPLICATION_JSON)
	public Complaint[] show() throws ClassNotFoundException, SQLException {
		return new Complaintdao().showdao();
	}
	
	@GET
	@Path("/show/{cmpid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Complaint search(@PathParam("cmpid") String cmpid) throws ClassNotFoundException, SQLException {
		return new Complaintdao().searchdao(cmpid);
	}
	
	@POST
	@Path("/insert")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String insert(Complaint cmp) throws ClassNotFoundException, SQLException {
		return new Complaintdao().insertdao(cmp);
	}
	
	@POST
	@Path("/resolve")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String resolve(Resolve res) throws ClassNotFoundException, SQLException {
		return new Complaintdao().resolve(res);
	}
}
