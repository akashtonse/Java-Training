package infinite.ComplaintServer;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Complaintdao {
	
	public String check(Complaint cmp) throws ClassNotFoundException, SQLException {
		Connection con=Connectionhelp.getconnection();
		String cmd="select resolvedate from resolve where ComplaintID=?";
		PreparedStatement ps=con.prepareStatement(cmd);
		ps.setString(1, cmp.getCompid());
		ResultSet rs=ps.executeQuery();
		rs.next();
		Date resdate=rs.getDate("resolvedate");
		long difference = resdate.getTime() - cmp.getCompdate().getTime();
		double daysBetween = (difference / (1000*60*60*24));
		int days=(int)daysBetween;
		days++;
		if(resdate.getTime()==cmp.getCompdate().getTime()) {
			return "green";
		}else if(days>=5) {
			return "pink";
		}else {
			return "red";
		}
	}
	
	public String resolve(Resolve res) throws ClassNotFoundException, SQLException {
		Complaint comp=searchdao(res.getCmpid());
		if(comp!=null) {
			Connection con=Connectionhelp.getconnection();
			String cmd="insert into resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,"
					+ "Comments) values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(cmd);
			ps.setString(1, res.getCmpid());
			ps.setDate(2, comp.getCompdate());
			long d1=System.currentTimeMillis();
			java.sql.Date date=new java.sql.Date(d1);
			ps.setDate(3, date);
			ps.setString(4, res.getName());
			ps.setString(5, res.getComments());
			ps.executeUpdate();
			
			cmd="update complaint set status='Resolved' where ComplaintID=?";
			PreparedStatement ps2=con.prepareStatement(cmd);
			ps2.setString(1, res.getCmpid());
			ps2.executeUpdate();
			return "Record added";
			
		}
		return "Invalid Complaint ID";
	}
	
	public Complaint searchdao(String cmpid) throws ClassNotFoundException, SQLException {
		Connection con=Connectionhelp.getconnection();
		String cmd="select * from complaint where ComplaintID=?";
		PreparedStatement ps=con.prepareStatement(cmd);
		ps.setString(1, cmpid);
		ResultSet rs=ps.executeQuery();
		Complaint cmp=null;
		while(rs.next()) {
			cmp=new Complaint();
			cmp.setCompid(rs.getString("complaintID"));
			cmp.setComptype(rs.getString("ComplaintType"));
			cmp.setDesc(rs.getString("CDescription"));
			cmp.setCompdate(rs.getDate("ComplaintDate"));
			cmp.setSeverity(rs.getString("Severity"));
			cmp.setStatus(rs.getString("status"));
		}
		return cmp;
	}
	
	public String insertdao(Complaint cmp) throws ClassNotFoundException, SQLException {
		Connection con=Connectionhelp.getconnection();
		String cmd="insert into complaint(complaintID,ComplaintType,CDescription,ComplaintDate"
				+ ",Severity) values(?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(cmd);
		ps.setString(1, cmp.getCompid());
		ps.setString(2, cmp.getComptype());
		ps.setString(3, cmp.getDesc());
		long d1=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(d1);
		ps.setDate(4, date);
		ps.setString(5, cmp.getSeverity());
		ps.executeUpdate();
		return "Record added";
	}
	
	public Complaint[] showdao() throws ClassNotFoundException, SQLException {
		Connection con=Connectionhelp.getconnection();
		String cmd="select * from complaint";
		PreparedStatement ps=con.prepareStatement(cmd);
		ResultSet rs=ps.executeQuery();
		List<Complaint> complist= new ArrayList<Complaint>();
		while(rs.next()) {
			Complaint cmp=new Complaint();
			cmp.setCompid(rs.getString("complaintID"));
			cmp.setComptype(rs.getString("ComplaintType"));
			cmp.setDesc(rs.getString("CDescription"));
			cmp.setCompdate(rs.getDate("ComplaintDate"));
			cmp.setSeverity(rs.getString("Severity"));
			cmp.setStatus(rs.getString("status"));
			complist.add(cmp);
		}
		return complist.toArray(new Complaint[complist.size()]);
	}
}
