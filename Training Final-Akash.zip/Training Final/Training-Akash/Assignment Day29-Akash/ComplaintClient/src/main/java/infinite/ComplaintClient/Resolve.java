package infinite.ComplaintClient;

import java.sql.Date;

public class Resolve {
	private String cmpid;
	private Date cmpdate;
	private Date resdate;
	private String name;
	private String comments;
	public Resolve(String cmpid, Date cmpdate, Date resdate, String name, String comments) {
	
		this.cmpid = cmpid;
		this.cmpdate = cmpdate;
		this.resdate = resdate;
		this.name = name;
		this.comments = comments;
	}
	public Resolve() {
	
		// TODO Auto-generated constructor stub
	}
	public String getCmpid() {
		return cmpid;
	}
	public void setCmpid(String cmpid) {
		this.cmpid = cmpid;
	}
	public Date getCmpdate() {
		return cmpdate;
	}
	public void setCmpdate(Date cmpdate) {
		this.cmpdate = cmpdate;
	}
	public Date getResdate() {
		return resdate;
	}
	public void setResdate(Date resdate) {
		this.resdate = resdate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Resolve [cmpid=" + cmpid + ", cmpdate=" + cmpdate + ", resdate=" + resdate + ", name=" + name
				+ ", comments=" + comments + "]";
	}
	
	
}
