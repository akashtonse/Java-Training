package com.infinite.lamda;

interface I4{
	void show();
}

public class Methodref {
	
	public void display() {
		System.out.println("hello world");
	}
	public static void main(String[] args) {
		Methodref obj=new Methodref();
		I4 obj2=obj::display;
		obj2.show();
		obj.display();
	}
}
