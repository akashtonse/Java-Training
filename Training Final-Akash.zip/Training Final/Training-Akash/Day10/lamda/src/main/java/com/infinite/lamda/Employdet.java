package com.infinite.lamda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Employdet {
	public static void main(String[] args) {
		List<Employ> emplist=new ArrayList<Employ>();
		emplist.add(new Employ(1,"Akash"));
		emplist.add(new Employ(10,"Akashgfdgs"));
		emplist.add(new Employ(12,"Akashdfsdgfda"));
		emplist.add(new Employ(2,"Akashtonse"));
		
		emplist.forEach(x -> System.out.println(x));
		System.out.println("---------------------------------");
		
		Collections.sort(emplist, (e1,e2) ->{
			return e1.getName().compareToIgnoreCase(e2.getName());
		});
		System.out.println("sorting name:");
		emplist.forEach(x -> System.out.println(x));
		
		Collections.sort(emplist, (e1,e2) ->{
			return e1.getEmpno()-e2.getEmpno();
		});
		System.out.println("---------------------------------");
		System.out.println("sorting employ number:");
		emplist.forEach(System.out::println);
	}
}
