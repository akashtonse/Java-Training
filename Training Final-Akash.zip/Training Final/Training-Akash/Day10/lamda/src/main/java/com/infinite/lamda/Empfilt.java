package com.infinite.lamda;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Empfilt {
	public static void main(String[] args) {
		List<Employ> emplist=new ArrayList<Employ>();
		emplist.add(new Employ(1,"Akash"));
		emplist.add(new Employ(10,"Akashgfdgs"));
		emplist.add(new Employ(12,"Akashdfsdgfda"));
		emplist.add(new Employ(2,"Akashtonse"));
		
		Stream<Employ> str=emplist.stream().filter(x -> x.getEmpno()>5);
		
		str.forEach(System.out::println);
		
		Stream<Employ> str2=emplist.stream().filter(x -> length(x.getName())>5);
		
		str2.forEach(System.out::println);
	}
	

	private static int length(String name) {
		// TODO Auto-generated method stub
		return 0;
	}

}
