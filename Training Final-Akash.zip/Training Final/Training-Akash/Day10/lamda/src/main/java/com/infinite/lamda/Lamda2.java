package com.infinite.lamda;

@FunctionalInterface
interface I3{
	int add(int a,int b);
}
public class Lamda2 {
	public static void main(String[] args) {
		I3 s=(a,b) ->{
			return a+b;
		};
		
		System.out.println(s.add(12, 12));
	}
}
