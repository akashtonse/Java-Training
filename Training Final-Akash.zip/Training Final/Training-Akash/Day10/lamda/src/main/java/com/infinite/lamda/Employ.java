package com.infinite.lamda;

public class Employ {
	private int empno;
	private String name;
	
	public Employ(int empno, String name) {
		
		this.empno = empno;
		this.name = name;
	}

	public Employ() {

		// TODO Auto-generated constructor stub
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employ [empno=" + empno + ", name=" + name + "]";
	}
	
}

