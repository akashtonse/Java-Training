package com.infinite.lamda;

interface I1{
	void display();
}

interface I2{
	String display();
}
public class Lamda1 {
	public static void main(String[] args) {
		I1 h1=() ->{
			System.out.println("hello world");
		};
		
		I1 h2=() ->{
			System.out.println("hello universe");
		};
		
		h1.display();
		h2.display();
		
		I2 a1=() ->{
			return "hello world";
		};
		I2 a2=() ->{
			return "hello universe";
		};
		System.out.println(a1.display());
		System.out.println(a2.display());
	}
}
