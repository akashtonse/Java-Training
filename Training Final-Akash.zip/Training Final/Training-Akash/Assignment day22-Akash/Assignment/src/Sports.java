
public class Sports extends Book{

	@Override
	public void bookname() {
		// TODO Auto-generated method stub
		System.out.println("Sports book1");
	}

	@Override
	public void author() {
		// TODO Auto-generated method stub
		System.out.println("Sports Author1");
	}

}
