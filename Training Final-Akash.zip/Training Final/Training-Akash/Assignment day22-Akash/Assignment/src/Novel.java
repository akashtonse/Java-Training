
public class Novel extends Book{

	@Override
	public void bookname() {
		System.out.println("Novel1");
		
	}

	@Override
	public void author() {
		System.out.println("NovelAuthor1");
		
	}

}
