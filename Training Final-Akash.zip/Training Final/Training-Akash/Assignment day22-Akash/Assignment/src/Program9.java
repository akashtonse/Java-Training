import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class Program9 {
	public static void main(String[] args) {
		List<Product> list=new ArrayList<Product>();
		list.add(new Product(1,"football",243.55));
		list.add(new Product(2,"basketball",243.55));
		list.add(new Product(3,"volleyball",243.55));
		list.add(new Product(4,"tennisball",243.55));
		list.add(new Product(5,"cricketball",243.55));
		list.add(new Product(6,"laptop1",240000));
		list.add(new Product(7,"television",24344.55));
		list.add(new Product(8,"book1",678.55));
		list.add(new Product(9,"laptop2",120000.55));
		list.add(new Product(10,"book2",243.55));
		
		System.out.println("Display using foreach:\n---------------------");
		for (Product product : list) {
			System.out.println(product);
		}
		System.out.println("----------------------------------------------------");
		System.out.println("Display using lamda:\n---------------------");
		list.forEach(x -> System.out.println(x));
		
		Collections.sort(list, (p1,p2)->{
			return p1.getName().compareToIgnoreCase(p2.getName());
		});
		System.out.println("\n----------------------------\nSorted using name:\n---------------------");
		list.forEach(x -> System.out.println(x));
		
		Stream<Product> str=list.stream().filter(x -> x.getPrice()>3000);
		System.out.println("\n----------------------------\nFiltered whose price > 3000\n------------------------");
		str.forEach(System.out::println);
	}
}
