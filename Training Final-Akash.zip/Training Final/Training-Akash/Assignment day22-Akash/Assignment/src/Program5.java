import java.util.Scanner;

public class Program5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the data:");
		String str=sc.next();
		char[] s=str.toCharArray();
		for(int i=0;i<str.length();i++) {
			if(s[i]>='a' && s[i]<='z') {
				int temp = (int) s[i];
		        temp = temp - 32;
		        s[i] = (char) temp;
			}
		}
		for (char c : s) {
			System.out.print(c);
		}
		
	}
}
