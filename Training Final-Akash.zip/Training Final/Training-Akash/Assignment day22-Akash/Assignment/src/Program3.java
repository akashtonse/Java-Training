
public class Program3 {
	public static void main(String[] args) {
		Sports s=new Sports();
		Novel n= new Novel();
		Academics a=new Academics();
	
	}
}
