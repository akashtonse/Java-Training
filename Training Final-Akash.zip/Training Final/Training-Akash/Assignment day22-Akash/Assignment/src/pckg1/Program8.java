package pckg1;

public class Program8 {
	private int a=1;
	public int b=2;
	protected int c=3;
	int d=4;
	public static void main(String[] args) {
		Program8 obj=new Program8();
		obj.check();
		One obj2=new One();
		obj2.check();
	}
	
	public void check() {
		System.out.println("private "+a);
		System.out.println("public "+b);
		System.out.println("protected "+c);
		System.out.println("friendly "+d);
	}
}



