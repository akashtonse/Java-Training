package pckg1;

public class One extends Program8 {
	
	public void check() {
		System.out.println("private not accessable in derived classes");
		System.out.println("public "+b);
	
		System.out.println("protected "+c);
		System.out.println("friendly "+d);
	}

}
