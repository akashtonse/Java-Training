
public class Academics extends Book {

	@Override
	public void bookname() {
		// TODO Auto-generated method stub
		System.out.println("Academy book1");
	}

	@Override
	public void author() {
		// TODO Auto-generated method stub
		System.out.println("Acedemy Author1");
	}

}
