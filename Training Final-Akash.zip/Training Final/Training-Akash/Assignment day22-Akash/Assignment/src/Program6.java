import java.util.Scanner;

public class Program6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string:");
		String str=sc.next();
		Program6 obj= new Program6();
		try {
			obj.check(str);
		} catch (SpecialException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void check(String s) throws SpecialException {
		if(s.contains(",")|| s.contains("@")||s.contains("%")||s.contains("#")
				||s.contains("$")) {
			throw new SpecialException("Invalid string");
		}else {
			System.out.println(s+" is valid");
		}
	}
}
