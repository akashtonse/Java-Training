package pckg2;
import pckg1.*;

public class Three extends Program8 {

	public void check() {
		System.out.println("private not accessable in different pckg ");
		System.out.println("public "+b);
		System.out.println("protected "+c);
		System.out.println("friendly not accessable in different pckg");
	}
	public static void main(String[] args) {
		Three obj= new Three();
		obj.check();
	}
}
