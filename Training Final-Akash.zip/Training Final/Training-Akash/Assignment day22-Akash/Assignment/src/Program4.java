import java.util.Scanner;

public class Program4 {
	public static void main(String[] args) {
		int h1,min1,h2,min2;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter time1(hr mins):");
		h1=sc.nextInt();
		min1=sc.nextInt();
		System.out.println("enter time2(hr mins):");
		h2=sc.nextInt();
		min2=sc.nextInt();
	
		int hresult=h1+h2;
		int minresult=min1+min2;
		if(minresult>=60) {
			hresult+=1;
			minresult=minresult-60;
		}
		System.out.println("Total time is "+hresult+"hrs "+minresult+"mins");
		
	}
}
