
public class SpecialException extends Exception {
	public SpecialException(){
		
	}
	public SpecialException(String error){
		super(error);
	}
}
