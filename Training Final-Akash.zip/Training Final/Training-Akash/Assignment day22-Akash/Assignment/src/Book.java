
public abstract class Book {
	public abstract void bookname();
	public abstract void author();
}
