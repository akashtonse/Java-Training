package com.java.p2;

public class CurrentBill {
	public static void main(String[] args) {
		double units=180,a=1.2,b=1.5,c=2,d=2.5,e=3;
		if (units<=100){
			System.out.println("bill is "+units*a);
		}else if (units>100 && units<=150){
			double bill=120+(units-100)*b;
			System.out.println("bill is "+bill);
		}else if (units>150 && units<=200){
			double bill=195+(units-150)*c;
			System.out.println("bill is "+bill);
		}else if (units>200 && units<=250){
			double bill=295+(units-200)*d;
			System.out.println("bill is "+bill);
		}else{
			double bill=420+(units-250)*e;
			System.out.println("bill is "+bill);
		}
	}
}
