package com.java.p2;

public class Str {
	public void change(){
		String str="Hello World";
		System.out.println("Length is "+str.length());
		System.out.println("lower case :"+str.toLowerCase());
		System.out.println("Uppercase: "+str.toUpperCase());
		System.out.println("Find 5th char: "+str.charAt(6));
		System.out.println("find position of 1st l: "+str.indexOf("l"));
	    String s1="akash",s2="abhishek",s3="akash";
	    System.out.println(s1.compareToIgnoreCase(s2));
	    System.out.println(s2.compareToIgnoreCase(s3));
	    System.out.println(s1.compareToIgnoreCase(s3));
	    System.out.println(s1.equals(s3));
	    String s4=s1.concat(s2);
	    System.out.println(s4);
	}
	public static void main(String[] args) {
		Str obj=new Str();
		obj.change();
	}
}
