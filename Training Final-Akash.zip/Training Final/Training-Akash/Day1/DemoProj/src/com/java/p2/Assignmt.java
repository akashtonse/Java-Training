package com.java.p2;

import java.math.*;
public class Assignmt {
	public static void main(String[] args) {
		String num1="43782479283743829723987493222222222222222222222228798";
		String num2="232343454444444444444444444444444232222222222222222222";
		BigInteger a=new BigInteger(num1);
		BigInteger b=new BigInteger(num2);
		System.out.println(a.multiply(b));
	}
}
