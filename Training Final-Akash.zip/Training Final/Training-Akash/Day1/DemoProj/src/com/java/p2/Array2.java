package com.java.p2;

public class Array2 {
	public void arr(){
		String[] s=new String[]{
				"Akash",
				"Abhishek",
				"Murali"
		};
		for (String string : s) {
			System.out.println(string);
		}
	}
	public static void main(String[] args) {
		Array2 obj=new Array2();
		obj.arr();
	}
}
