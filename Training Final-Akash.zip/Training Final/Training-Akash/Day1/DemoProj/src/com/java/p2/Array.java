package com.java.p2;

public class Array {
	public void arr(){
		int[] a=new int[] {1,2,3,4,5};
		for ( int i : a) {
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		Array obj=new Array();
		obj.arr();
	}
}
