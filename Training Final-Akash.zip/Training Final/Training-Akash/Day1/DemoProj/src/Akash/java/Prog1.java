package Akash.java;

public class Prog1 {
	public static void main(String[] args) {
		String name="Akash";
		int a,b;a=10;b=20;
		System.out.println("Name is "+name);
		System.out.println("Numbers are "+a);
		System.out.println("Number is "+b);
	}
}
