package Akash.java;

public class Case2 {
	public void select(String name){
		switch(name){
		case "akash":
			System.out.println("AKASH");
			break;
		case "abhishek":
			System.out.println("ABHISHEK");
			break;
		default:
			System.out.println("INVALID");
			break;
		}
	}
	public static void main(String[] args) {
		String name="akash";int a=3;
		Case2 obj = new Case2();
		obj.select(name);
		Case obj2=new Case();
		obj2.match(a);
	}
}
