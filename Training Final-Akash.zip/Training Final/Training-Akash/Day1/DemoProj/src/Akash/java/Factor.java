package Akash.java;

public class Factor {
	public void find(int n){
		
		for(int i=1;i<=n;i++){
			if (n%i==0){
				System.out.println("factor is "+i);
			}
		}
	}
	public static void main(String[] args) {
		int n=10;
		Factor obj=new Factor();
		obj.find(n);
	}
}
