package Akash.java;

public class Fact {
	public void fact(int n){
		int f=1,i=1;
		while(i<=n){
			f=f*i;
			i++;
		}
		System.out.println("factorial is "+f);
	}
	public static void main(String[] args) {
		int n=4;
		Fact obj = new Fact();
		obj.fact(n);
	}
}
