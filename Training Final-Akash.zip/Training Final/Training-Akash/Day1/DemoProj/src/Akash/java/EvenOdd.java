package Akash.java;

public class EvenOdd {
	public void find(int n){
		if (n%2==0){
			System.out.println("even number");
		}else{
			System.out.println("Odd number");
		}
	}
	public static void main(String[] args) {
		int a=7;
		EvenOdd obj = new EvenOdd();
		obj.find(a);
	}
}
