package Akash.java;

public class Circle {
	public void get(double r){
		double area=3.14*r*r;
		double circumference=2*3.14*r;
		System.out.println("area is "+area);
		System.out.println("circumference is "+circumference);
	}
	public static void main(String[] args) {
		double r=4.56;
		Circle obj = new Circle();
		obj.get(r);
	}
}
