package Akash.java;

public class Impl2 {
	public static void main(String[] args) {
		Prog2 obj =new Prog2();
		obj.akash();
		obj.murali();
	}
}
