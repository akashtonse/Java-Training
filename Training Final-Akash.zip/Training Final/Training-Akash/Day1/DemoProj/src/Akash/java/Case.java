package Akash.java;

public class Case {
	public void match(int a){
		switch(a){
		case 1:
			System.out.println("ONE");break;
		case 2:
			System.out.println("TWO");break;
		case 3:
			System.out.println("THREE");break;
		default:
			System.out.println("INVALID");break;
		}
	}
	public static void main(String[] args) {
		int a=10;
		Case obj=new Case();
		obj.match(a);
	}
}
