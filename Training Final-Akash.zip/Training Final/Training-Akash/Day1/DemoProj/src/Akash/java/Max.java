package Akash.java;

public class Max {
	public void find(int a, int b, int c){
		int m=a;
		if (m<b){
			m=b;
		}
		if (m<c){
			m=c;
		}
		System.out.println("Maximum number is "+m);
	}
	public static void main(String[] args) {
		int a=10,b=20,c=30;
		Max obj = new Max();
		obj.find(a, b, c);
	}
}
