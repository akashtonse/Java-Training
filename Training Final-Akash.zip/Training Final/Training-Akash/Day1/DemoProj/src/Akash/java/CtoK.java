package Akash.java;

public class CtoK {
	public void convert(double temp){
		double kelvin=temp+273.15;
		System.out.println("Temperature in Kelvin is "+kelvin);
	}
	public static void main(String[] args) {
		double cel=45.56;
		CtoK obj = new CtoK();
		obj.convert(cel);
	}
}
