package Akash.java;

public class PosNeg {
	public void find(int a){
		if (a<=0){
			System.out.println("negative number");
		}else{
			System.out.println("positive number");
		}
	}
	public static void main(String[] args) {
		int n=-20;
		PosNeg obj = new PosNeg();
		obj.find(n);
	}
}
