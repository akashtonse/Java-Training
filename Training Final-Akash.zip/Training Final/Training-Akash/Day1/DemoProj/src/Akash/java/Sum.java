package Akash.java;

public class Sum {
	public void find(int a, int b){
		int sum=a+b;
		System.out.println("sum is "+sum);
	}
	public static void main(String[] args) {
		int a=10,b=20;
		Sum obj = new Sum();
		obj.find(a, b);
	}
}
