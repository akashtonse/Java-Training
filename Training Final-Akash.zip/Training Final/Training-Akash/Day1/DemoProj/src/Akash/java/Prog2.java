package Akash.java;

public class Prog2 {
	public void akash(){
		System.out.println("I am Akash..");
	}
	private void abhishek(){
		System.out.println("I am Abhishek");
	}
	void murali(){
		System.out.println("I am Murali");
	}
	public static void main(String[] args) {
		Prog2 obj=new Prog2();
		obj.abhishek();
	}
}
