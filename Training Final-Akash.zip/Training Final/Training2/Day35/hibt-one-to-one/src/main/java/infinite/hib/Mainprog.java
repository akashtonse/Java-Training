package infinite.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Mainprog {
	public static void main(String[] args) {
		StandardServiceRegistry ssr=
				new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
		    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build(); 
		    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
		    Session s=factory.openSession();
		    
		    Transaction t=s.beginTransaction();
		    Employee emp=new Employee();
		    emp.setName("akash");
		    emp.setEmail("akashtonse1@gmail.com");
		    
		    Address add=new Address();
		    add.setAddressLine1("bagina");
		    add.setCity("udupi");
		    add.setState("Karnataka");
		    add.setCountry("India");
		    add.setPincode(576213);
		    emp.setAddress(add);
		    add.setEmployee(emp);
		    
		    s.save(emp);
		    t.commit();
		    
		    System.out.println("Success");
	}
}
