package infinite.hib;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ShowMain {
	public static void main(String[] args) {
		StandardServiceRegistry ssr=
				new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
		    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build(); 
		    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
		    Session s=factory.openSession();
		    
		    Query q=s.createQuery("from Employee");
		    List<Employee> lst=q.list();
		    
		    for (Employee emp : lst) {
				System.out.println(emp.getEmployeeId()+" "+emp.getName()+" "+emp.getEmail());
				Address add=emp.getAddress();
				System.out.println(add.getAddressId()+" "+add.getAddressLine1()+" "+add.getCity()+" "+add.getState()+" "+
				add.getCountry()+" "+add.getPincode());
			}
	}
}
