package infinite.hib;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ShowMain {
	public static void main(String[] args) {
		StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	    
	    Query q=session.createQuery("from Question");
	    List<Question> lst=q.list();
	    for (Question ques : lst) {
			System.out.println(ques.getId()+" "+ques.getQname());
			List<Answer> lst2=ques.getAnswers();
			System.out.println("Answer: ");
			for (Answer ans : lst2) {
				System.out.println(ans.getAnswername()+" by "+ans.getPostedBy());
			}
			System.out.println();
		}
	}
}
