package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class VendorService {
	@Autowired
	private VendorRepo repo;
	
	@Autowired
	private Vendordao dao;
	
	public String auth(String name,String pwd) {
		return dao.authenticate(name, pwd);
	}
	
	public List<Vendor> showVendor(){
		return repo.findAll();
	}
	
	public Vendor search(int vid) {
		return repo.findById(vid).get();
	}
}
