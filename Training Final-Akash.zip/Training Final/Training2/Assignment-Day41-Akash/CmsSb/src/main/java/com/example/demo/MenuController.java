package com.example.demo;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MenuController {
	@Autowired
	private MenuService service;
	
	@RequestMapping("/showMenu")
	public List<Menu> showMenu(){
		return service.showMenu();
	}
	
	@RequestMapping("/showMenu/{mid}")
	public ResponseEntity<Menu> search(@PathVariable int mid){
		try {
			Menu menu = service.search(mid);
			return new ResponseEntity<Menu>(menu,HttpStatus.OK);
			} catch(NoSuchElementException e) {
				return new ResponseEntity<Menu>(HttpStatus.NOT_FOUND);
			}
	}
}
