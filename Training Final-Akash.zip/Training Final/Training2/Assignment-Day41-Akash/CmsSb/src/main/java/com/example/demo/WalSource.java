package com.example.demo;

public enum WalSource {
	PAYTM,CREDITCARD,DEBITCARD
}
