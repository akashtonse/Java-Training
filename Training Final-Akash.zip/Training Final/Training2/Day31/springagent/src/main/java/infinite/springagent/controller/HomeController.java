package infinite.springagent.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import infinite.springagent.dao.Agentdao;
import infinite.springagent.model.Agent;



@Controller
public class HomeController {
	
	@Autowired
	private Agentdao agentdao;
	
	@RequestMapping(value = "/updateagent",method = RequestMethod.POST)
	public ModelAndView updateemp(@ModelAttribute Agent agent) {
		agentdao.update(agent);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/editemploy")
	public ModelAndView editemp(HttpServletRequest request) {
		int id=Integer.parseInt(request.getParameter("id"));
		Agent agent=agentdao.search(id);
		 ModelAndView model = new ModelAndView("agentsearchform");
		    model.addObject("agent", agent);
		 
		    return model;
	}
	
	@RequestMapping(value = "/deleteagent")
	public ModelAndView deleteemp(HttpServletRequest request) {
		int id=Integer.parseInt(request.getParameter("id"));
		agentdao.delete(id);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/saveagent",method = RequestMethod.POST)
	public ModelAndView saveemp(@ModelAttribute Agent agent) {
		agentdao.add(agent);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/addagent",method = RequestMethod.GET)
	public ModelAndView addagent(ModelAndView mod) {
		Agent agent=new Agent();
		mod.addObject("agent",agent);
		mod.setViewName("agentform");
		return mod;
	}
	
	@RequestMapping(value="/")
	public ModelAndView showall(ModelAndView mod) throws IOException{
		List<Agent> agentlist=agentdao.showall();
		mod.addObject("agentlist",agentlist);
		mod.setViewName("home");
		return mod;
	}
}
