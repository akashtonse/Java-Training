package infinite.springagent.model;

public class Agent {
	private int agentId;
	private String name;
	private String city;
	private int maritalstatus;
	private double premium;
	public Agent(int agentId, String name, String city, double premium, int maritalstatus) {
		
		this.agentId = agentId;
		this.name = name;
		this.city = city;
		this.maritalstatus=maritalstatus;
		this.premium = premium;
	}
	public Agent() {
	
		// TODO Auto-generated constructor stub
	}
	public int getAgentId() {
		return agentId;
	}
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	@Override
	public String toString() {
		return "Agent [agentId=" + agentId + ", name=" + name + ", city=" + city + ", premium=" + premium + "]";
	}
	public int getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(int maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	
	
}
