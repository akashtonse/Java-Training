package infinite.springagent.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import infinite.springagent.model.Agent;


public class AgentImpl implements Agentdao {
	
	static JdbcTemplate jdb;
	
	public AgentImpl(DataSource getdatasource) {
		this.jdb= new JdbcTemplate(getdatasource);
	}

	@Override
	public List<Agent> showall() {
		 String sql = "SELECT * FROM agent";
		    List<Agent> listAgent = jdb.query(sql, new RowMapper<Agent>() {
		 
		        @Override
		        public Agent mapRow(ResultSet rs, int rowNum) throws SQLException {
		            Agent agent=new Agent();
		            agent.setAgentId(rs.getInt("agentID"));
		            agent.setName(rs.getString("name"));
		            agent.setCity(rs.getString("city"));
		            agent.setMaritalstatus(rs.getInt("maritalstatus"));
		            agent.setPremium(rs.getDouble("premium"));
		            return agent;
		        }
		 
		    });
		 
		    return listAgent;
	}

	@Override
	public Agent search(int id) {
		String sql = "select * from agent where agentID=?";
	    return jdb.query(sql,new Object[] {id}, new ResultSetExtractor<Agent>() {
	        @Override
	        public Agent extractData(ResultSet rs) throws SQLException,
	                DataAccessException {
	            if (rs.next()) {
	            	Agent agent=new Agent();
		            agent.setAgentId(rs.getInt("agentID"));
		            agent.setName(rs.getString("name"));
		            agent.setCity(rs.getString("city"));
		            agent.setMaritalstatus(rs.getInt("maritalstatus"));
		            agent.setPremium(rs.getDouble("premium"));
		            return agent;
	            }
	 
	            return null;
	        }
	 
	    });
	}

	@Override
	public void add(Agent agent) {
		String cmd = "insert into agent(agentID,name,city,"
				+ "maritalstatus,premium) values(?,?,?,?,?)";
		 jdb.update(cmd, agent.getAgentId(),agent.getName(),agent.getCity(),agent.getMaritalstatus()
				 ,agent.getPremium());
		
	}

	@Override
	public void update(Agent agent) {
		String cmd = "Update agent set name=?, city=?,  "
				+ " maritalstatus=?,premium=? WHERE agentID=?";
		 jdb.update(cmd, agent.getName(),agent.getCity(),agent.getMaritalstatus()
				 ,agent.getPremium(),agent.getAgentId());
		
	}

	@Override
	public void delete(int id) {
		String sql = "DELETE FROM agent WHERE agentID=?";
	    jdb.update(sql, id);
		
		
	}

}
