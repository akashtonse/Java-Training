package infinite.springagent.dao;

import java.util.List;

import infinite.springagent.model.Agent;



public interface Agentdao {
	List<Agent> showall();
	Agent search(int id);
	void add(Agent agent);
	void update(Agent agent);
	void delete(int id);
}
