package com.example.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@RequestMapping("/")
	public String helloWorldBean()  
	{  
		return "Welcome to Spring Boot Beans"; //constructor of HelloWorldBean  
	} 
	
	@RequestMapping("/sum/{a}/{b}")
	public String sum(@PathVariable int a, @PathVariable int b) {
		int c=a+b;
		String res="";
		res+=c;
		return res;
	}
	
	@RequestMapping("/akash/{name}")
	public String fullname(@PathVariable String name) {
		return "Name is akash "+name;
	}
}
