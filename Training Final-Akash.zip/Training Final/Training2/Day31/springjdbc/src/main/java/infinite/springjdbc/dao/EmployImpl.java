package infinite.springjdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import infinite.springjdbc.model.Employ;

public class EmployImpl implements Employdao {
	
	static JdbcTemplate jdb;
	
	public EmployImpl(DataSource getdatasource) {
		this.jdb= new JdbcTemplate(getdatasource);
	}

	@Override
	public List<Employ> showall() {
		 String sql = "SELECT * FROM Employ";
		    List<Employ> listEmploy = jdb.query(sql, new RowMapper<Employ>() {
		 
		        @Override
		        public Employ mapRow(ResultSet rs, int rowNum) throws SQLException {
		            Employ employ = new Employ();
		            employ.setEmpno(rs.getInt("empno"));
		            employ.setName(rs.getString("name"));		           
		            employ.setDept(rs.getString("dept"));		  
		            employ.setBasic(rs.getInt("basic"));
		 
		            return employ;
		        }
		 
		    });
		 
		    return listEmploy;
	}

	@Override
	public Employ search(int empno) {
		String sql = "select * from Employ where empno=?";
	    return jdb.query(sql,new Object[] {empno}, new ResultSetExtractor<Employ>() {
	        @Override
	        public Employ extractData(ResultSet rs) throws SQLException,
	                DataAccessException {
	            if (rs.next()) {
	                Employ employ = new Employ();
		            employ.setEmpno(rs.getInt("empno"));
		            employ.setName(rs.getString("name"));
		            employ.setDept(rs.getString("dept"));
		            employ.setBasic(rs.getInt("basic"));
		            return employ;
	            }
	 
	            return null;
	        }
	 
	    });
	}

	@Override
	public void add(Employ emp) {
		String cmd = "insert into Employ(empno,name,dept,"
				+ "basic) values(?,?,?,?)";
		 jdb.update(cmd, emp.getEmpno(),emp.getName(), 
				 emp.getDept(),emp.getBasic());
		
	}

	@Override
	public void update(Employ emp) {
		String cmd = "Update employ set name=?, Dept=?,  "
				+ " Basic=? WHERE Empno=?";
		 jdb.update(cmd, emp.getName(),emp.getDept(),emp.getBasic(),emp.getEmpno());
		
	}

	@Override
	public void delete(int empno) {
		String sql = "DELETE FROM Employ WHERE empno=?";
	    jdb.update(sql, empno);
		
	}

}
