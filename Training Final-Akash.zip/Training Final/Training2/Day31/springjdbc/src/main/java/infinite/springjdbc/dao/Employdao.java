package infinite.springjdbc.dao;

import java.util.List;

import infinite.springjdbc.model.Employ;

public interface Employdao {
	List<Employ> showall();
	Employ search(int empno);
	void add(Employ emp);
	void update(Employ emp);
	void delete(int empno);
}
