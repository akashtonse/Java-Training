package infinite.jsf;

public class Users {

}
