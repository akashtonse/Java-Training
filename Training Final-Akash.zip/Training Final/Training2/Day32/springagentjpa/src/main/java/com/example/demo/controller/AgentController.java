package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AgentController {

	@Autowired
	private AgentService service;
	
	@RequestMapping("/")
	public List<Agent> showall(){
		return service.showall();
	}
	
	@RequestMapping("/agent/{id}")
	public Agent search(@PathVariable int id) {
		return service.search(id);
	}
	
	@PostMapping("/addagent")
	public String addagent(@RequestBody Agent agent) {
		return service.addagent(agent);
	}
}
