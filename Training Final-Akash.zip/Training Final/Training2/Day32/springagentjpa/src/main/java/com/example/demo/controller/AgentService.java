package com.example.demo.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class AgentService {

		@Autowired
		private AgentRepo repo;
		
		public List<Agent> showall(){
			return repo.findAll();
		}
		
		public Agent search(int id) {
			return repo.findById(id).get();
		}
		
		public String addagent(Agent agent) {
			repo.save(agent);
			return "Record inserted";
		}
}
