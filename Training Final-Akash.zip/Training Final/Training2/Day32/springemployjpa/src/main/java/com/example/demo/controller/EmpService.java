package com.example.demo.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class EmpService {
	
	@Autowired
	private EmpRepo repo;
	
	public List<Employ> showall(){
		return repo.findAll();
	}
	
	public Employ search(int empno) {
		return repo.findById(empno).get();
	}
	
	public void addemp(Employ emp) {
		repo.save(emp);
	}
	
}
