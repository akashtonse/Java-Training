package com.example.demo.controller;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpRepo extends JpaRepository<Employ, Integer> {
	
}
