package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmpController {
	
	@Autowired
	private EmpService service;
	
	@RequestMapping("/")
	public List<Employ> showall(){
		return service.showall();
	}
	
	@RequestMapping("/employ/{empno}")
	public Employ search(@PathVariable int empno) {
		return service.search(empno);
	}
	
	@PostMapping("/addemploy")
	public void addemp(@RequestBody Employ emp) {
		service.addemp(emp);
	}
}
