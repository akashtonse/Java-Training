package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringemployjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringemployjpaApplication.class, args);
	}

}
