package infinite.hibernateemploy;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class EmpDelete {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Employ No:");
		int empno=sc.nextInt();
		
		SessionFactory sf=Sessionhelp.getsession();
		Session s=sf.openSession();
		
		Query q=s.createQuery("from Employ where empno="+empno);
		List<Employ> emplist=q.list();
		Employ emp=emplist.get(0);
		Transaction t=s.beginTransaction();
		s.delete(emp);
		t.commit();
	}
}
