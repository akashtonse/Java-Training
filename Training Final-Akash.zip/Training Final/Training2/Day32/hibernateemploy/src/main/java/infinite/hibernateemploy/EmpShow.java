package infinite.hibernateemploy;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class EmpShow {
	public static void main(String[] args) {
		
		SessionFactory sf=Sessionhelp.getsession();
		Session s=sf.openSession();
		
		Query q=s.createQuery("from Employ");
		List<Employ> emplist=q.list();
		for (Employ employ : emplist) {
			System.out.print("Employ NO "+employ.getEmpno());
			System.out.print(" Employ Name: "+employ.getName());
			System.out.print(" Department: "+employ.getDept());
			System.out.println(" Salary: "+employ.getBasic());
		}
	}
}
