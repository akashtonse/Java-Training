package infinite.RestClient;

public class Agent {
	private int agentID;
	private String name;
	private String city;
	private int maritalstatus;
	private double premium;
	public Agent(int agentID, String name, String city, int maritalstatus, double premium) {
		
		this.agentID = agentID;
		this.name = name;
		this.city = city;
		this.maritalstatus = maritalstatus;
		this.premium = premium;
	}
	public Agent() {
	
		// TODO Auto-generated constructor stub
	}
	public int getAgentID() {
		return agentID;
	}
	public void setAgentID(int agentID) {
		this.agentID = agentID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(int maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	@Override
	public String toString() {
		return "Agent [agentID=" + agentID + ", name=" + name + ", city=" + city + ", maritalstatus=" + maritalstatus
				+ ", premium=" + premium + "]";
	}
	
	
}
