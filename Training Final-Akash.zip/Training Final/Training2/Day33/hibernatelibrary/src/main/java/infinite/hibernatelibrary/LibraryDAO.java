package infinite.hibernatelibrary;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class LibraryDAO {

	static SessionFactory sf;
	static Session session;
	static Query query;
	static {
		sf = SessionHelper.getFactory();
		session = sf.openSession();
	}
	
	public List<TransReturn> history(String user) {
		query = session.createQuery("from TransReturn where userName='" + user + "'");

		List<TransReturn> lst = query.list();
		if (lst.isEmpty()) {
			return null;
		} else {
			return lst;
		}
	}
	
	public void UpdateBook(TransBook tb) {

		Transaction t = session.beginTransaction();
		
		query = session.createQuery("from Books where id=" + tb.getBookId());
		List<Books> lst = query.list();

	
		Books b1 = new Books();
		if (lst.size() > 0) {
			for (Books b2 : lst) {
				b1=b2;
				//b2.setTotalbooks(b2.getTotalbooks() + 1);

			}
			 b1.setTotalbooks(b1.getTotalbooks()+1);
		}

		session.save(b1);
		t.commit();
		
	}
	
	public int returnbook(String user,int bookid) throws ParseException {
		query = session.createQuery("from TransBook where userName='" + user + "' and bookid=" + bookid);
		List<TransBook> lst = query.list();

		TransBook tb=new TransBook();
		TransReturn tr= new TransReturn();;
		int days;
		if (lst.isEmpty()) {
			return -1;
		} else {

			for (TransBook tb1 : lst) {
				tb = tb1;
			}
		

			String fdate = tb.getFromDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date idate = sdf.parse(fdate);
			Date rdate = new Date();
			days = (int) ((rdate.getTime() - idate.getTime()) / (1000 * 60 * 60 * 24));
			tr.setBookid(bookid);
			tr.setUserName(user);
			tr.setFromdate(fdate);
			tr.setToDate(sdf.format(rdate));

			Transaction t = session.beginTransaction();

			session.save(tr);
			t.commit();
		
			UpdateBook(tb);
			
			t=session.beginTransaction();
			tb.setBookId(bookid);
			session.delete(tb);
			t.commit();

			return days;}
	}
	
	public List<TransBook> showIssuedBooks(String user) {
		query = session.createQuery("from TransBook where userName='" + user + "'");

		List<TransBook> lst = query.list();
		if (lst.isEmpty()) {
			return null;
		} else {
			return lst;
		}
	}
	
	public List<Books> searchBooks(String searchtype, String searchvalue) {

		if (searchtype.equals("id"))
			query = session.createQuery("from Books where id=" + Integer.parseInt(searchvalue));
		else if (searchtype.equalsIgnoreCase("dept"))
			query = session.createQuery("from Books where dept='" + searchvalue + "'");

		else if (searchtype.equalsIgnoreCase("bookname"))
			query = session.createQuery("from Books where name='" + searchvalue + "'");

		else if (searchtype.equalsIgnoreCase("authorname"))
			query = session.createQuery("from Books where author='" + searchvalue + "'");
		else
			query = session.createQuery("from Books where name!='" + searchvalue + "' or 1=1");

		List<Books> lst = query.list();

		if (lst.isEmpty())
			return null;
		else
			return lst;

	}

	public String issuedOrNot(String user, int bid) {

		query = session.createQuery("from TransBook where userName='" + user + "' and bookId=" + bid);
		List<TransBook> lst = query.list();

		if (!lst.isEmpty()) {
			return "yes";
		} else {
			return "no";
		}
	}
	public void issueBook(TransBook tb) {
		
		Transaction t = session.beginTransaction();
		session.save(tb);
		t.commit();

		t=session.beginTransaction();
		query = session.createQuery("from Books where id=" + tb.getBookId());
		List<Books> lst = query.list();

		// Transaction t1 = s.beginTransaction();
//		t.begin();
		Books b1 = new Books();
		if (lst.size() > 0) {
			for (Books b2 : lst) {
				b1 = b2;
				// b2.setTotalbooks(b2.getTotalbooks() - 1);

			}
			b1.setTotalbooks(b1.getTotalbooks() - 1);
		}

		session.save(b1);
		t.commit();
		
	}
	public int loginCheck(LibUsers lib) {

		query = session.createQuery(
				"from LibUsers where username='" 
						+ lib.getUsername() + "' and password='" 
						+ lib.getPassword() + "'");
		List<LibUsers> lst = query.list();

		if (lst.isEmpty())
			return 0;
		else
			return 1;

	}

}
