package infinite.test;

import java.util.List;

import javax.faces.bean.ManagedBean;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

@ManagedBean(name="agentdao")
public class Agentdao {
	
	public Agent[] showAgent() {
		StandardServiceRegistry ssr=
				new StandardServiceRegistryBuilder().configure("hibernate2.cfg.xml").build();  
		    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build(); 
		    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
		    Session session=factory.openSession();  
		
		Query q = session.createQuery("from Agent");
		List<Agent> agentList= q.list();
		return agentList.toArray(new Agent[agentList.size()]);
	}
}
