package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class Leavedao {

	@Autowired
	private JdbcTemplate jdb;
	
	public String updateStatus(int lid,String status,String comments) {
		String cmd = "Update leave_history set LEAVE_STATUS=? AND LEAVE_MNGR_COMMENTS WHERE lid=?";
		jdb.update(cmd, new Object[] {status,comments,lid});
		return "Leave updated";
	}
	
	public void updateEmp(int noofdays) {
		String cmd = "update Employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL-?";
		jdb.update(cmd,new Object[] {noofdays});
	}
	
	public void updateEmpdeny(int noofdays) {
		String cmd = "update Employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL+?";
		jdb.update(cmd,new Object[] {noofdays});
	}
	
	public List<LeaveHistory> showEmployHistory(int empId) {
		String cmd = "select * from Leave_History where emp_id=?";
		List<LeaveHistory> leaveList=null;
		leaveList=jdb.query(cmd,new Object[] {empId}, new RowMapper<LeaveHistory>() {

			@Override
			public LeaveHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
				LeaveHistory lh = new LeaveHistory();
				lh.setLeaveId(rs.getInt("LEAVE_ID"));
				lh.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				lh.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				lh.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				lh.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				lh.setLeaveType(rs.getString("LEAVE_TYPE"));
				lh.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				lh.setLeaveReason(rs.getString("LEAVE_REASON"));
				return lh;
			}
			
		});
		return leaveList;
	}
	
	public List<LeaveHistory> showEmployPending(int empId) {
		String cmd = "select * from Leave_History where emp_id=? AND LEAVE_STATUS='PENDING'";
		List<LeaveHistory> leaveList=null;
		leaveList=jdb.query(cmd,new Object[] {empId}, new RowMapper<LeaveHistory>() {

			@Override
			public LeaveHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
				LeaveHistory lh = new LeaveHistory();
				lh.setLeaveId(rs.getInt("LEAVE_ID"));
				lh.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				lh.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				lh.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				lh.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				lh.setLeaveType(rs.getString("LEAVE_TYPE"));
				lh.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				lh.setLeaveReason(rs.getString("LEAVE_REASON"));
				return lh;
			}
			
		});
		return leaveList;
	}
}
