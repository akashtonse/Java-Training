package com.example.demo;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveController {

	@Autowired
	private LeaveService service;
	

	@PostMapping("/acceptOrReject/{lid}/{mid}/{status}/{comments}")
	public String acceptOrReject(@PathVariable int lid,@PathVariable int mid, 
			@PathVariable String status,@PathVariable String comments) {
		return service.acceptorreject(lid, mid, status, comments);
	}
	
	@PostMapping("/applyLeave")
	public String add(@RequestBody LeaveHistory lh) {
		return service.applyLeave(lh);
	}
	
	@RequestMapping(value="/employLeaveHistory/{eid}")
	public List<LeaveHistory> employLeaveHistory(@PathVariable int eid) {
		return service.showEmployHistory(eid);
	}

	@RequestMapping(value="/employPending/{eid}")
	public List<LeaveHistory> employPending(@PathVariable int eid) {
		return service.showEmployPending(eid);
	}
	
	@RequestMapping("/showLeave/{lid}")
	public ResponseEntity<LeaveHistory> search(@PathVariable int lid){
		try {
			LeaveHistory leave = service.search(lid);
			return new ResponseEntity<LeaveHistory>(leave,HttpStatus.OK);
			} catch(NoSuchElementException e) {
				return new ResponseEntity<LeaveHistory>(HttpStatus.NOT_FOUND);
			}
	}
}
