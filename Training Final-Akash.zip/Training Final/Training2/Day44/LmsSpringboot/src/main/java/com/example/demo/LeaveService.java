package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveService {

	@Autowired
	private LeaveRepo repo;
	
	@Autowired
	private Leavedao dao;
	
	@Autowired
	private EmpRepo emprepo;
	
	public String acceptorreject(int lid,int mid,String status,String comments) {
		LeaveHistory lh = repo.findById(lid).get();
		Employee emp=emprepo.findById(lh.getEmpId()).get();
		if (mid!=emp.getEmpManagerId()) {
			return "You are unauthorized manager...";
		} 
		if (status.toUpperCase().equals("YES")) {
			return dao.updateStatus(lid,"APPROVED",comments);
		} else {
			dao.updateEmpdeny(lh.getLeaveNoOfDays());
			return dao.updateStatus(lid, "DENIED",comments);
			
			
		}
	}
	
	public String applyLeave(LeaveHistory lh) {
		Employee emp=emprepo.findById(lh.getEmpId()).get();
		int availleave=emp.getEmpAvailLeaveBal();
		
		if (availleave >=lh.getLeaveNoOfDays()) {
			repo.save(lh);
			dao.updateEmp(lh.getLeaveNoOfDays());
			return "Leave applied";
		}
		return "Insufficient leaves available..";
	}
	
	public List<LeaveHistory> showEmployHistory(int empId){
		return dao.showEmployHistory(empId);
	}
	
	public List<LeaveHistory> showEmployPending(int empId){
		return dao.showEmployPending(empId);
	}
	
	public LeaveHistory search(int lid) {
		return repo.findById(lid).get();
	}
}
