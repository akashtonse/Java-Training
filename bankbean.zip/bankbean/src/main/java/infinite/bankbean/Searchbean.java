package infinite.bankbean;

import java.sql.SQLException;

public class Searchbean {
	private int accno;

	public Searchbean() {
		
		// TODO Auto-generated constructor stub
	}

	public Searchbean(int accno) {
		
		this.accno = accno;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	@Override
	public String toString() {
		return "Searchbean [accno=" + accno + "]";
	}
	
	public Bank search() throws ClassNotFoundException, SQLException {
		Bank bk=new Bankdao().search(accno);
		return bk;
	}
}
