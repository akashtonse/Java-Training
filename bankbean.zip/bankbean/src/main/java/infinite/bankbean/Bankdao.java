package infinite.bankbean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Bankdao {
	Connection con;
	PreparedStatement ps;
	
	public Transaction[] ministate() throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getConnection();
		String cmd = "select * from trans order by transdate desc";
		ps = con.prepareStatement(cmd);
		ResultSet rs = ps.executeQuery();
		List<Transaction> transList = new ArrayList<Transaction>();
		Transaction tst = null;
		int count=0;
		while(rs.next()) {
			tst= new Transaction();
			tst.setAccno(rs.getInt("AccountNo"));
			tst.setAmount(rs.getDouble("TransAmount"));
			tst.setTransdate(rs.getDate("TransDate"));
			tst.setTranstype(rs.getString("TransType"));
			transList.add(tst);
			count++;
			if(count>=10) {
				break;
			}
		}
		return transList.toArray(new Transaction[transList.size()]);
	}
	
	public String withdraw(int accno,int amount) throws ClassNotFoundException, SQLException {
		Bank bank2=search(accno);
		if(bank2!=null) {
			if((bank2.getAmount()-amount>1000)) {
				con=Connectionhelp.getConnection();
				String cmd="update bank set amount=amount-? where accountno=?";
				ps=con.prepareStatement(cmd);
				ps.setInt(1, amount);
				ps.setInt(2, accno);
				ps.executeUpdate();
				
				cmd="insert into Trans(AccountNo,TransAmount,TransType) values(?,?,?)";
				ps=con.prepareStatement(cmd);
				ps.setInt(1, accno);
				ps.setInt(2, amount);
				ps.setString(3, "Debit");
				ps.executeUpdate();
				return "Amount withdrawn";
			}
			return "insufficient funds";
		}
		return "Account  invalid";
	}
	
	public String deposit(int accno,int amount) throws ClassNotFoundException, SQLException {
		Bank bank2=search(accno);
		if(bank2!=null) {
			con=Connectionhelp.getConnection();
			String cmd="update bank set amount=amount+? where accountno=?";
			ps=con.prepareStatement(cmd);
			ps.setInt(1, amount);
			ps.setInt(2, accno);
			ps.executeUpdate();
			
			cmd="insert into Trans(AccountNo,TransAmount,TransType) values(?,?,?)";
			ps=con.prepareStatement(cmd);
			ps.setInt(1, accno);
			ps.setInt(2, amount);
			ps.setString(3, "Cred");
			ps.executeUpdate();
			return "Amount deposited";
		}
		return "Account  invalid";
	}
	
	public String update(Bank bank) throws ClassNotFoundException, SQLException {
		Bank bank2=search(bank.getAccountno());
		if(bank2!=null) {
			con=Connectionhelp.getConnection();
			String cmd="update bank set firstname=?,lastname=?,city=?,state=?, amount=?,cheqfacil=?,accounttype=? where accountno=?";
			ps=con.prepareStatement(cmd);
			ps.setString(1, bank.getFirstname());
			ps.setString(2, bank.getLastname());
			ps.setString(3, bank.getCity());
			ps.setString(4, bank.getState());
			ps.setInt(5, bank.getAmount());
			ps.setString(6, bank.getCheqfacil());
			ps.setString(7, bank.getAccounttype());
			ps.setInt(8, bank.getAccountno());
			ps.executeUpdate();
			return "Account updated";
		}
		return "Account  invalid";
	}
	
	public String deactivate(int accno) throws ClassNotFoundException, SQLException {
		Bank bank=search(accno);
		if(bank!=null) {
			con=Connectionhelp.getConnection();
			String cmd="update bank set status='inactive' where accountno=?";
			ps=con.prepareStatement(cmd);
			ps.setInt(1, accno);
			ps.executeUpdate();
			return "Account deactivated";
		}
		return "Account  invalid";
	}
	public int getaccnum() throws ClassNotFoundException, SQLException {
		con=Connectionhelp.getConnection();
		String cmd="select case when max(accountno) is null then 1 else max(accountno)+1 end accno from bank";
		ps=con.prepareStatement(cmd);
		ResultSet rs=ps.executeQuery();
		rs.next();
		int accno=rs.getInt("accno");
		return accno;
	}
	
	public String createacc(Bank bank) throws ClassNotFoundException, SQLException {
		bank.setAccountno(getaccnum());
		con=Connectionhelp.getConnection();
		String cmd="insert into bank(accountno,firstname,lastname,city,state,amount,cheqfacil,accounttype)"
				+ "values(?,?,?,?,?,?,?,?)";
		ps=con.prepareStatement(cmd);
		ps.setInt(1,bank.getAccountno());
		ps.setString(2, bank.getFirstname());
		ps.setString(3, bank.getLastname());
		ps.setString(4, bank.getCity());
		ps.setString(5, bank.getState());
		ps.setInt(6, bank.getAmount());
		ps.setString(7, bank.getCheqfacil());
		ps.setString(8, bank.getAccounttype());
		ps.executeUpdate();
		return "Account created";
		
	}
	
	public Bank search(int accno) throws ClassNotFoundException, SQLException {
		con=Connectionhelp.getConnection();
		String cmd="select * from bank where accountno=?";
		ps=con.prepareStatement(cmd);
		ps.setInt(1, accno);
	    ResultSet rs=ps.executeQuery();
		Bank bank=null;
		while(rs.next()) {
			bank = new Bank();
			bank.setAccountno(rs.getInt("accountNo"));
			bank.setFirstname(rs.getString("FirstName"));
			bank.setLastname(rs.getString("LastName"));
			bank.setCity(rs.getString("city"));
			bank.setState(rs.getString("state"));
			bank.setAmount(rs.getInt("amount"));
			bank.setCheqfacil(rs.getString("cheqFacil"));
			bank.setAccounttype(rs.getString("accountType"));
		}
		return bank;
	}
}
