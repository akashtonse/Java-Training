package infinite.bankbean;

import java.sql.SQLException;

public class Createaccountbean {
	private String firstname;
	private String lastname;
	private String city;
	private String state;
	private int amount;
	private String cheqfacil;
	private String accounttype;
	public Createaccountbean() {
	
		// TODO Auto-generated constructor stub
	}
	public Createaccountbean(String firstname, String lastname, String city, String state, int amount, String cheqfacil,
			String accounttype) {

		this.firstname = firstname;
		this.lastname = lastname;
		this.city = city;
		this.state = state;
		this.amount = amount;
		this.cheqfacil = cheqfacil;
		this.accounttype = accounttype;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getCheqfacil() {
		return cheqfacil;
	}
	public void setCheqfacil(String cheqfacil) {
		this.cheqfacil = cheqfacil;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	@Override
	public String toString() {
		return "Createaccountbean [firstname=" + firstname + ", lastname=" + lastname + ", city=" + city + ", state="
				+ state + ", amount=" + amount + ", cheqfacil=" + cheqfacil + ", accounttype=" + accounttype + "]";
	}
	public String create() throws ClassNotFoundException, SQLException {
		Bank bk=new Bank();
		bk.setAccountno(new Bankdao().getaccnum());
		bk.setFirstname(firstname);
		bk.setLastname(lastname);
		bk.setCity(city);
		bk.setState(state);
		bk.setAmount(amount);
		bk.setCheqfacil(cheqfacil);
		bk.setAccounttype(accounttype);
		return new Bankdao().createacc(bk);
	}
	
}
