package infinite.bankbean;

import java.sql.SQLException;

public class Deactivatebean {
	private int accno;

	public Deactivatebean() {
		
		// TODO Auto-generated constructor stub
	}

	public Deactivatebean(int accno) {
		
		this.accno = accno;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	@Override
	public String toString() {
		return "Searchbean [accno=" + accno + "]";
	}
	
	public String deactivate() throws ClassNotFoundException, SQLException {
		return new Bankdao().deactivate(accno);
	}
}
