package infinite.bankbean;

import java.sql.Date;

public class Transaction {
	private int accno;
	private double amount;
	private Date transdate;
	private String transtype;
	public Transaction() {
	
		// TODO Auto-generated constructor stub
	}
	public Transaction(int accno, double amount, Date transdate, String transtype) {

		this.accno = accno;
		this.amount = amount;
		this.transdate = transdate;
		this.transtype = transtype;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Date getTransdate() {
		return transdate;
	}
	public void setTransdate(Date transdate) {
		this.transdate = transdate;
	}
	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	@Override
	public String toString() {
		return "Transaction [accno=" + accno + ", amount=" + amount + ", transdate=" + transdate + ", transtype="
				+ transtype + "]";
	}
	
	
}
