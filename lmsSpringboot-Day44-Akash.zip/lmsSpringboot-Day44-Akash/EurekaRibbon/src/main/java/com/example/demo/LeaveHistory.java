package com.example.demo;

import java.sql.Date;




public class LeaveHistory {
	
	
	private int leaveId;
	private int leaveNoOfDays;
	private String leaveMngrComments;
	private int empId;
	private Date leaveStartDate;
	private Date leaveEndDate;
	private String leaveType;
	private String leaveStatus;
	private String leaveReason;
	public LeaveHistory(int leaveId, int leaveNoOfDays, String leaveMngrComments, int empId, Date leaveStartDate,
			Date leaveEndDate, String leaveType, String leaveStatus, String leaveReason) {
	
		this.leaveId = leaveId;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveMngrComments = leaveMngrComments;
		this.empId = empId;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.leaveType = leaveType;
		this.leaveStatus = leaveStatus;
		this.leaveReason = leaveReason;
	}
	public LeaveHistory() {
		
		// TODO Auto-generated constructor stub
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getLeaveNoOfDays() {
		return leaveNoOfDays;
	}
	public void setLeaveNoOfDays(int leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}
	public String getLeaveMngrComments() {
		return leaveMngrComments;
	}
	public void setLeaveMngrComments(String leaveMngrComments) {
		this.leaveMngrComments = leaveMngrComments;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public Date getLeaveStartDate() {
		return leaveStartDate;
	}
	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}
	public Date getLeaveEndDate() {
		return leaveEndDate;
	}
	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public String getLeaveReason() {
		return leaveReason;
	}
	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}
	
	
}
