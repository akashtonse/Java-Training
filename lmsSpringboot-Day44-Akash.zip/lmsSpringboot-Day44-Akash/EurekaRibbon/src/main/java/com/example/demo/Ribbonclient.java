package com.example.demo;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@RestController
public class Ribbonclient {

	@Autowired
	private LoadBalancerClient lba;
	
	@PostMapping(value= "/acceptOrReject/{lid}/{mid}/{status}/{comments}")
	public String acceptorreject(@PathVariable int lid,@PathVariable int mid, 
			@PathVariable String status,@PathVariable String comments) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/acceptOrReject/"+lid+"/"+mid+"/"+status+"/"+comments;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		//ResponseEntity<Object[]> res=null;
		try{
			//res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return response.getBody();
	}
	
	@PostMapping(value= "/post/leave")
	public String applyLeave(@RequestBody LeaveHistory lh) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/applyLeave";

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		//ResponseEntity<Object[]> res=null;
		try{
			//res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return response.getBody();
	}
	
	@GetMapping(value= "/fetch/emppending/{eid}")
	public Object[] getEmployeePending(@PathVariable int eid) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/employPending/"+eid;

		RestTemplate restTemplate= new RestTemplate();
		//ResponseEntity<String> response= null;
		
		ResponseEntity<Object[]> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			//response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return res.getBody();
	}
	
	@GetMapping(value= "/fetch/emphistory/{eid}")
	public Object[] getEmployeeHistory(@PathVariable int eid) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/employLeaveHistory/"+eid;

		RestTemplate restTemplate= new RestTemplate();
		//ResponseEntity<String> response= null;
		
		ResponseEntity<Object[]> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			//response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return res.getBody();
	}
	
	@GetMapping(value= "/fetch/leave/{lid}")
	public String getLeave(@PathVariable int lid) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showLeave/"+lid;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		//ResponseEntity<Object[]> res=null;
		try{
			//res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return response.getBody();
	}
	
	@GetMapping(value= "/fetch/employ/{eid}")
	public String searchEmployee(@PathVariable int eid) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showEmployee/"+eid;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		//ResponseEntity<Object[]> res=null;
		try{
			//res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return response.getBody();
	}
	
	@GetMapping(value= "/fetch")
	public Object[] getEmployee() throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("lmsclient");

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showEmployee";

		RestTemplate restTemplate= new RestTemplate();
		//ResponseEntity<String> response= null;
		
		ResponseEntity<Object[]> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			//response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
	
		return res.getBody();
	}
	
	

	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}