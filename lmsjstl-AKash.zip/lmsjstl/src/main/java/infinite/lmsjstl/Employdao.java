package infinite.lmsjstl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Employdao {
	Connection con;
	PreparedStatement ps;
	
	public Employ search(int empid) throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getconnection();
		String cmd = "select * from employee where emp_id=?";
		ps = con.prepareStatement(cmd);
		ps.setInt(1,empid);
		ResultSet rs = ps.executeQuery();
		Employ emp = null;
		if (rs.next()) {
			emp=new Employ();
			emp.setEmpid(rs.getInt("emp_id"));
			emp.setEmpname(rs.getString("EMP_NAME"));
			emp.setMail(rs.getString("EMP_MAIL"));
			emp.setMgrid(rs.getInt("EMP_MANAGER_ID"));
			emp.setLeaveavail(rs.getInt("EMP_AVAIL_LEAVE_BAL"));
		} 
		return emp;
	}
}
