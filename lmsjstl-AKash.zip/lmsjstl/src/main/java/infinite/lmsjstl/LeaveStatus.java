package infinite.lmsjstl;

public enum LeaveStatus {
	PENDING,APPROVED,DENIED
}
