package infinite.lmsjstl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Leavedao {
	Connection con;
	PreparedStatement ps;
	
	public String applydeny(int mgrid,int leaveid,String mgrcomment,String status) throws ClassNotFoundException, SQLException {
		Leave lv=search(leaveid);
		if(lv!=null) {
			Employ emp=new Employdao().search(lv.getEmp_id());
			if(emp.getMgrid()==mgrid) {
				if(status.equalsIgnoreCase("YES")) {
					con = Connectionhelp.getconnection();
					String cmd="update leave_history set LEAVE_MNGR_COMMENTS=?,LEAVE_STATUS=? where leave_id=?";
					ps = con.prepareStatement(cmd);
					ps.setString(1, mgrcomment);
					ps.setString(2, LeaveStatus.APPROVED.toString());
					ps.setInt(3, leaveid);
					ps.executeUpdate();
					return "Leave updated ";
				}else if(status.equalsIgnoreCase("NO")) {
					String cmd="update leave_history set LEAVE_MNGR_COMMENTS=?,LEAVE_STATUS=? where leave_id=?";
					ps = con.prepareStatement(cmd);
					ps.setString(1, mgrcomment);
					ps.setString(2, LeaveStatus.DENIED.toString());
					ps.setInt(3, leaveid);
					ps.executeUpdate();
					
					cmd="update employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL+? where emp_id=?";
					ps = con.prepareStatement(cmd);
					ps.setInt(1, lv.getNo_of_days());
					ps.setInt(2, lv.getEmp_id());
					ps.executeUpdate();
					
					return "Leave updated ";
				}else {
					return "invalid status";
				}
			}
			return "You are not authorized";
		}
		return "invalid leave id";
	}
	
	public Leave[] leavehistory(int empid) throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getconnection();
		String cmd = "select * from leave_history where emp_id=?";
		ps = con.prepareStatement(cmd);
		ps.setInt(1, empid);
		ResultSet rs = ps.executeQuery();
		List<Leave> leaveList = new ArrayList<Leave>();
		Leave leave = null;
		while(rs.next()) {
			leave = new Leave();
			leave.setLeave_id(rs.getInt("leave_id"));
			leave.setNo_of_days(rs.getInt("leave_no_of_days"));
			leave.setMgr_comment(rs.getString("LEAVE_MNGR_COMMENTS"));
			leave.setEmp_id(rs.getInt("EMP_ID"));
			leave.setStart_date(rs.getDate("LEAVE_START_DATE"));
			leave.setEnd_date(rs.getDate("LEAVE_END_DATE"));
			leave.setLeavetype(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leave.setLeavestatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leave.setLeave_reason(rs.getString("LEAVE_REASON"));
			leaveList.add(leave);
		}
		return leaveList.toArray(new Leave[leaveList.size()]);
	}
	
	public Leave[] pendingleaves(int empid) throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getconnection();
		String cmd = "select * from leave_history where emp_id=? and LEAVE_STATUS='PENDING' ";
		ps = con.prepareStatement(cmd);
		ps.setInt(1, empid);
		ResultSet rs = ps.executeQuery();
		List<Leave> leaveList = new ArrayList<Leave>();
		Leave leave = null;
		while(rs.next()) {
			leave = new Leave();
			leave.setLeave_id(rs.getInt("leave_id"));
			leave.setNo_of_days(rs.getInt("leave_no_of_days"));
			leave.setMgr_comment(rs.getString("LEAVE_MNGR_COMMENTS"));
			leave.setEmp_id(rs.getInt("EMP_ID"));
			leave.setStart_date(rs.getDate("LEAVE_START_DATE"));
			leave.setEnd_date(rs.getDate("LEAVE_END_DATE"));
			leave.setLeavetype(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leave.setLeavestatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leave.setLeave_reason(rs.getString("LEAVE_REASON"));
			leaveList.add(leave);
		}
		return leaveList.toArray(new Leave[leaveList.size()]);
	}
	
	public Leave[] show() throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getconnection();
		String cmd = "select * from leave_history";
		ps = con.prepareStatement(cmd);
		ResultSet rs = ps.executeQuery();
		List<Leave> leaveList = new ArrayList<Leave>();
		Leave leave = null;
		while(rs.next()) {
			leave = new Leave();
			leave.setLeave_id(rs.getInt("leave_id"));
			leave.setNo_of_days(rs.getInt("leave_no_of_days"));
			leave.setMgr_comment(rs.getString("LEAVE_MNGR_COMMENTS"));
			leave.setEmp_id(rs.getInt("EMP_ID"));
			leave.setStart_date(rs.getDate("LEAVE_START_DATE"));
			leave.setEnd_date(rs.getDate("LEAVE_END_DATE"));
			leave.setLeavetype(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leave.setLeavestatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leave.setLeave_reason(rs.getString("LEAVE_REASON"));
			leaveList.add(leave);
		}
		return leaveList.toArray(new Leave[leaveList.size()]);
	}
	
	public Leave search(int leaveid) throws ClassNotFoundException, SQLException {
		con = Connectionhelp.getconnection();
		String cmd = "select * from leave_history where leave_id=?";
		ps = con.prepareStatement(cmd);
		ps.setInt(1, leaveid);
		ResultSet rs = ps.executeQuery();
		Leave leave = null;
		if (rs.next()) {
			leave = new Leave();
			leave.setLeave_id(rs.getInt("leave_id"));
			leave.setNo_of_days(rs.getInt("leave_no_of_days"));
			leave.setMgr_comment(rs.getString("LEAVE_MNGR_COMMENTS"));
			leave.setEmp_id(rs.getInt("EMP_ID"));
			leave.setStart_date(rs.getDate("LEAVE_START_DATE"));
			leave.setEnd_date(rs.getDate("LEAVE_END_DATE"));
			leave.setLeavetype(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leave.setLeavestatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leave.setLeave_reason(rs.getString("LEAVE_REASON"));
		} 
		return leave;
	}
	public String addleave(Leave leave) throws ClassNotFoundException, SQLException {
		java.util.Date d1=new java.util.Date();
		long difference = leave.getEnd_date().getTime() - leave.getStart_date().getTime();
		double daysBetween = (difference / (1000*60*60*24));
		leave.setNo_of_days((int)daysBetween);
		if(leave.getNo_of_days()>0) {
			if(leave.getStart_date().getTime()>d1.getTime() && leave.getEnd_date().getTime()>d1.getTime()) {
				con = Connectionhelp.getconnection();
				String cmd = "insert into leave_history(LEAVE_NO_OF_DAYS,LEAVE_MNGR_COMMENTS"
						+ ",EMP_ID,LEAVE_START_DATE,LEAVE_END_DATE,LEAVE_REASON) "
						+ " values(?,?,?,?,?,?)";
				ps = con.prepareStatement(cmd);
				ps.setInt(1, leave.getNo_of_days());
				ps.setString(2, leave.getMgr_comment());
				ps.setInt(3, leave.getEmp_id());
				ps.setDate(4, leave.getStart_date());
				ps.setDate(5, leave.getEnd_date());
				ps.setString(6, leave.getLeave_reason());
				ps.executeUpdate();
				
				cmd="update employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL-? where EMP_ID=?";
				ps = con.prepareStatement(cmd);
				ps.setInt(1, leave.getNo_of_days());
				ps.setInt(2, leave.getEmp_id());
				ps.executeUpdate();
				return "Record Inserted...";
			}
			return "start date or end date cannot be before today";
		}
		return "invalid dates";
	}
	
	
}
