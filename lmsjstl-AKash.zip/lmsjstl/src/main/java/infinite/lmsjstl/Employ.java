package infinite.lmsjstl;

public class Employ {
	private String empname;
	private int empid;
	private String mail;
	private int mgrid;
	private int leaveavail;
	public Employ() {
	
		// TODO Auto-generated constructor stub
	}
	public Employ(String empname, int empid, String mail, int mgrid, int leaveavail) {
	
		this.empname = empname;
		this.empid = empid;
		this.mail = mail;
		this.mgrid = mgrid;
		this.leaveavail = leaveavail;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public int getMgrid() {
		return mgrid;
	}
	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}
	public int getLeaveavail() {
		return leaveavail;
	}
	public void setLeaveavail(int leaveavail) {
		this.leaveavail = leaveavail;
	}
	@Override
	public String toString() {
		return "Employ [empname=" + empname + ", empid=" + empid + ", mail=" + mail + ", mgrid=" + mgrid
				+ ", leaveavail=" + leaveavail + "]";
	}
	
	
	
}
