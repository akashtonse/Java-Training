package infinite.lmsjstl;

public enum LeaveType {
	EL
}
