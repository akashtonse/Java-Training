package infinite.lmsjstl;

import java.sql.Date;

//import java.util.Date;

public class Leave {
	private int leave_id;
	private int no_of_days;
	private String mgr_comment;
	private int emp_id;
	private Date start_date;
	private Date end_date;
	private String leave_reason;
	private LeaveStatus leavestatus;
	private LeaveType leavetype;
	public Leave() {

		// TODO Auto-generated constructor stub
	}
	public Leave(int leave_id, int no_of_days, String mgr_comment, int emp_id, Date start_date, Date end_date,
			String leave_reason, LeaveStatus leavestatus, LeaveType leavetype) {
	
		this.leave_id = leave_id;
		this.no_of_days = no_of_days;
		this.mgr_comment = mgr_comment;
		this.emp_id = emp_id;
		this.start_date = start_date;
		this.end_date = end_date;
		this.leave_reason = leave_reason;
		this.leavestatus = leavestatus;
		this.leavetype = leavetype;
	}
	public int getLeave_id() {
		return leave_id;
	}
	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}
	public int getNo_of_days() {
		return no_of_days;
	}
	public void setNo_of_days(int no_of_days) {
		this.no_of_days = no_of_days;
	}
	public String getMgr_comment() {
		return mgr_comment;
	}
	public void setMgr_comment(String mgr_comment) {
		this.mgr_comment = mgr_comment;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getLeave_reason() {
		return leave_reason;
	}
	public void setLeave_reason(String leave_reason) {
		this.leave_reason = leave_reason;
	}
	public LeaveStatus getLeavestatus() {
		return leavestatus;
	}
	public void setLeavestatus(LeaveStatus leavestatus) {
		this.leavestatus = leavestatus;
	}
	public LeaveType getLeavetype() {
		return leavetype;
	}
	public void setLeavetype(LeaveType leavetype) {
		this.leavetype = leavetype;
	}
	@Override
	public String toString() {
		return "Leave [leave_id=" + leave_id + ", no_of_days=" + no_of_days + ", mgr_comment=" + mgr_comment
				+ ", emp_id=" + emp_id + ", start_date=" + start_date + ", end_date=" + end_date + ", leave_reason="
				+ leave_reason + ", leavestatus=" + leavestatus + ", leavetype=" + leavetype + "]\n";
	}
	
	
}
