package infinite.ComplaintServer;

import java.sql.Date;

public class Complaint {
	private String compid;
	private String comptype;
	private String desc;
	private Date compdate;
	private String severity;
	private String status;
	public Complaint(String compid, String comptype, String desc, Date compdate, String severity, String status) {
		
		this.compid = compid;
		this.comptype = comptype;
		this.desc = desc;
		this.compdate = compdate;
		this.severity = severity;
		this.status=status;
	}
	public Complaint() {

		// TODO Auto-generated constructor stub
	}
	public String getCompid() {
		return compid;
	}
	public void setCompid(String compid) {
		this.compid = compid;
	}
	public String getComptype() {
		return comptype;
	}
	public void setComptype(String comptype) {
		this.comptype = comptype;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Date getCompdate() {
		return compdate;
	}
	public void setCompdate(Date compdate) {
		this.compdate = compdate;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	@Override
	public String toString() {
		return "Complaint [compid=" + compid + ", comptype=" + comptype + ", desc=" + desc + ", compdate=" + compdate
				+ ", severity=" + severity + ", status=" +status+ "]";
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
